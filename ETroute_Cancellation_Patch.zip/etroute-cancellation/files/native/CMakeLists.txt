cmake_minimum_required(VERSION 3.22)
project(etroute_native_supervisor LANGUAGES CXX)

add_library(etroute_native_supervisor STATIC
    src/native_supervisor.cpp
)

set_target_properties(etroute_native_supervisor PROPERTIES
    POSITION_INDEPENDENT_CODE ON
)

target_include_directories(etroute_native_supervisor
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_compile_features(etroute_native_supervisor PUBLIC cxx_std_20)

target_compile_options(etroute_native_supervisor PRIVATE
    -Wall
    -Wextra
    -Wpedantic
    -Werror
)

if(ANDROID)
    add_library(etroute_native_supervisor_jni SHARED
        src/jni_native_supervisor.cpp
    )

    target_include_directories(etroute_native_supervisor_jni
        PRIVATE
            ${CMAKE_CURRENT_SOURCE_DIR}/include
    )

    target_compile_features(etroute_native_supervisor_jni PRIVATE cxx_std_20)

    target_compile_options(etroute_native_supervisor_jni PRIVATE
        -Wall
        -Wextra
        -Wpedantic
        -Werror
    )

    target_link_libraries(etroute_native_supervisor_jni
        PRIVATE
            etroute_native_supervisor
    )

    set_target_properties(etroute_native_supervisor_jni PROPERTIES
        OUTPUT_NAME "etroute_native_supervisor"
    )
endif()

option(ETROUTE_BUILD_NATIVE_TESTS "Build native supervisor and JNI ABI contract tests" OFF)

if(ETROUTE_BUILD_NATIVE_TESTS)
    add_executable(etroute_cancellation_test tests/cancellation_test.cpp)
    target_link_libraries(etroute_cancellation_test PRIVATE etroute_native_supervisor)
    target_compile_features(etroute_cancellation_test PRIVATE cxx_std_20)

    add_executable(etroute_native_supervisor_smoke
        tests/native_supervisor_smoke.cpp
    )
    target_link_libraries(etroute_native_supervisor_smoke
        PRIVATE
            etroute_native_supervisor
    )

    add_executable(etroute_jni_abi_contract_test
        tests/jni_abi_contract_test.cpp
    )
    target_include_directories(etroute_jni_abi_contract_test
        PRIVATE
            ${CMAKE_CURRENT_SOURCE_DIR}/include
    )
    target_compile_features(etroute_jni_abi_contract_test PRIVATE cxx_std_20)
    target_compile_options(etroute_jni_abi_contract_test PRIVATE
        -Wall
        -Wextra
        -Wpedantic
        -Werror
    )
endif()
