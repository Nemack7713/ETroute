# ETroute request cancellation patch

This is one scoped cancellation change. No Chaquopy, Compose, Activity, Gradle or validator-suite changes. It is not an APK or a connected Stop button.

Upload and extract this ZIP in /workspaces/ETroute, then run:

    python3 etroute-cancellation/install.py

The installer checks every changed source against the supplied baseline before writing, backs up old files, and rolls back writes on failure. It refuses differing sources. The package also includes a new native cancellation test and its CMake target.

Host verification commands:

    cmake -S native -B /tmp/etroute-cancel-check -DETROUTE_BUILD_NATIVE_TESTS=ON
    cmake --build /tmp/etroute-cancel-check -j2
    /tmp/etroute-cancel-check/etroute_jni_abi_contract_test
    /tmp/etroute-cancel-check/etroute_native_supervisor_smoke
    /tmp/etroute-cancel-check/etroute_cancellation_test

## Kotlin integration contract

After actual launch validation, call supervisor.prepare(validatedLaunch) BEFORE dispatching to a worker. Retain that request as the active request. Worker calls request.run() exactly once. Stop calls that same request.cancel(), without blocking the UI. Cancel before run is retained; repeated cancel is harmless; a token cannot signal another request. Never derive or signal a PID from UI input. Clear the active request only if it is still that same instance.

The current EtRouteSessionRunner has not been altered: its ordinary run calls still work but do not expose a request to UI. Wiring this handle into the runner and terminal is the next integration step. Do not bypass PreparedLaunchValidator to use the new API.

Cancellation uses Java AtomicBoolean, queried by JNI only on its calling worker thread and by the native parent, never by the forked child. Old nativeRun remains exported. JNI ABI v1's seven result fields and all old values remain; optional cancellation capability version 1 and stages CANCELLED=14 / CLEANUP_UNCONFIRMED=15 are added. New Kotlin probes the capability when preparing; a stale native library fails before launch. Rebuild Kotlin and the native library together. Existing policy version 2 remains unchanged.

CANCELLED means cancellation won the race and the original process group was observed absent. timedOut remains false. A child which exits before cancellation is observed can report normal completion. Cleanup that cannot confirm leader reaping/group disappearance returns CLEANUP_UNCONFIRMED with nonzero errno. Leave session files intact for that result. Cancellation and timeout wait up to 500 ms for original-group disappearance AFTER termination/leader reaping; this is not a hard total time bound (kernel waitpid may block).

Process groups are not a sandbox. Descendants can escape with setsid/setpgid; the check covers the original group only. Normal-success cleanup of background descendants is not changed. File cleanup remains the controller/finalizer's responsibility and must not start on merely requesting cancellation. This change does not establish safety for untrusted scripts.

## Validation performed here

Compiled with g++ C++20 and warnings-as-errors: existing success, exec failure, timeout, and process-tree smoke passed. New pre-launch cancellation, SIGTERM-resistant SIGKILL cancellation, concurrent independent request and timeout distinction checks passed. Existing ABI contract test also passed on the patched headers.

CMake unavailable here; compilation used g++ directly. JNI and Kotlin compilation, JVM token test, Android NDK compilation and device testing are NOT verified: JNI headers, javac, Gradle and Kotlin compiler are unavailable. The included JNI test harness documents an unexecuted check; it is not a passing test result.
