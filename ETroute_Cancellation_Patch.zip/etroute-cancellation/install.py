# Run from the ETroute root: python3 etroute-cancellation/install.py
from pathlib import Path
import hashlib
import json
import shutil
import datetime

package = Path(__file__).resolve().parent
root = Path.cwd()
manifest = json.loads((package / 'baseline.json').read_text())
for name, expected in manifest.items():
    target = root / name
    if target.is_symlink() or root not in target.resolve().parents:
        raise SystemExit('Unsafe destination: ' + name)
    actual = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    if actual != expected:
        raise SystemExit('Source differs; nothing changed: ' + name)
backup = root / ('etroute-cancellation-backup-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir()
written = []
try:
    for name, expected in manifest.items():
        target = root / name
        if expected is not None:
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        written.append(name)
        shutil.copyfile(package / 'files' / name, target)
except BaseException:
    for name in reversed(written):
        target = root / name
        if manifest[name] is None:
            target.unlink(missing_ok=True)
        else:
            shutil.copy2(backup / name, target)
    raise
print('PATCH_APPLIED')
print('BACKUP=' + str(backup))
