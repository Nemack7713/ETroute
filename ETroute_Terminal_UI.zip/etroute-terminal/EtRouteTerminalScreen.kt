package com.etroute.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collect

// Publish state from the real controller. STOPPING lasts until termination is confirmed.
enum class RuntimePhase {
    UNAVAILABLE, READY, STARTING, RUNNING, STOPPING, COMPLETED, FAILED
}

data class TerminalLine(val id: Long, val text: String, val isError: Boolean = false)

data class TerminalUiState(
    val phase: RuntimePhase = RuntimePhase.UNAVAILABLE,
    val runtimeLabel: String = "Runtime not verified",
    val sessionId: String? = null,
    val lines: List<TerminalLine> = emptyList(),
    val droppedLines: Long = 0,
) {
    val canRun: Boolean get() = phase in setOf(
        RuntimePhase.READY, RuntimePhase.COMPLETED, RuntimePhase.FAILED
    )
    val canStop: Boolean get() = phase == RuntimePhase.STARTING || phase == RuntimePhase.RUNNING
}

// Use per session, from one serialized controller context. Persist full logs separately.
class BoundedTerminalLog(
    private val maxLines: Int = 1000,
    private val maxLineChars: Int = 4096,
) {
    init { require(maxLines > 0); require(maxLineChars > 0) }
    private val entries = ArrayDeque<TerminalLine>()
    private var nextId = 0L
    var droppedLines: Long = 0
        private set

    // Pass decoded lines, not an unbounded output stream or a whole log file.
    fun appendLine(text: String, isError: Boolean = false) {
        val clipped = if (text.length > maxLineChars) text.take(maxLineChars) + "… [truncated]" else text
        entries.addLast(TerminalLine(nextId++, clipped, isError))
        if (entries.size > maxLines) { entries.removeFirst(); droppedLines++ }
    }
    // Clear only the display buffer; keep IDs monotonic and diagnostic files intact.
    fun clearDisplay() {
        entries.clear()
        droppedLines = 0
    }
    fun snapshot(): List<TerminalLine> = entries.toList()
}

// No runtime dependency: the host owns validation, launching, stopping and session lifetime.
@Composable
fun EtRouteTerminalScreen(
    state: TerminalUiState,
    onRun: (String) -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
    onClearDisplay: (() -> Unit)? = null,
) {
    var input by rememberSaveable { mutableStateOf("") }
    var followOutput by rememberSaveable { mutableStateOf(true) }
    val keyboard = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    val lastId = state.lines.lastOrNull()?.id

    // Manual scrolling pauses automatic following; resume with the explicit checkbox.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { scrolling ->
            if (scrolling && listState.canScrollForward) followOutput = false
        }
    }
    LaunchedEffect(lastId, followOutput) {
        if (followOutput && state.lines.isNotEmpty() && !listState.isScrollInProgress) {
            listState.scrollToItem(state.lines.lastIndex)
        }
    }

    Column(
        modifier.fillMaxSize().safeDrawingPadding().imePadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("ETuMAX / ETroute", style = MaterialTheme.typography.titleLarge)
        Text("${state.phase.name} · ${state.runtimeLabel}", style = MaterialTheme.typography.bodySmall)
        state.sessionId?.let { Text("Session: $it", style = MaterialTheme.typography.labelSmall) }
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Script path for controller validation") },
            singleLine = true,
            enabled = state.canRun,
            modifier = Modifier.fillMaxWidth(),
        )
        Surface(
            modifier = Modifier.fillMaxWidth().weight(1f),
            color = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Column(Modifier.padding(8.dp)) {
                Row {
                    Checkbox(checked = followOutput, onCheckedChange = { followOutput = it })
                    Text("Follow output", modifier = Modifier.padding(top = 12.dp))
                    Spacer(Modifier.weight(1f))
                    onClearDisplay?.let { clear ->
                        TextButton(onClick = clear) { Text("Clear") }
                    }
                }
                if (state.droppedLines > 0) {
                    Text("${state.droppedLines} older lines omitted", style = MaterialTheme.typography.labelSmall)
                }
                LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().weight(1f)) {
                    items(state.lines, key = { it.id }) { line ->
                        SelectionContainer {
                            Text(
                                text = if (line.isError) "[stderr] ${line.text}" else line.text,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (line.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
        // Keep actions outside the scrolling output and above the keyboard.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onRun(input.trim()) },
                enabled = state.canRun && input.isNotBlank(),
                modifier = Modifier.weight(1f),
            ) { Text("Run") }
            OutlinedButton(
                onClick = {
                    // Signal termination first; keyboard dismissal never delays the request.
                    onStop()
                    keyboard?.hide()
                },
                enabled = state.canStop,
                modifier = Modifier.weight(1f),
            ) { Text(if (state.phase == RuntimePhase.STOPPING) "Stopping…" else "Stop") }
        }
    }
}
