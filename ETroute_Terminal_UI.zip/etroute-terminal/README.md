# ETroute terminal UI component

Chaquopy-free source component for an existing Android Jetpack Compose / Material 3 project. This is not a standalone APK project or an implemented NativeSupervisor adapter.

## Integration

Copy EtRouteTerminalScreen.kt into your app source set and adjust its package if needed. Dependencies are Compose foundation, runtime-saveable and Material 3, using the versions already validated by your project. Host it inside your existing MaterialTheme. Handle edge-to-edge window configuration in the Activity; avoid applying the same insets again in the parent.

Call EtRouteTerminalScreen(state, onRun, onStop). Publish immutable TerminalUiState snapshots from your controller/ViewModel and collect them with your app's lifecycle-aware state mechanism. onRun receives a script path, never a shell command. Validate it using your actual launch validator before execution. onStop requests supervisor termination; do not mark completion merely because cancellation was requested. Keep runtime/session ownership out of the composable lifecycle.

Initial state is UNAVAILABLE. READY means the controller has verified the runtime. FAILED and COMPLETED permit another launch only while that runtime remains usable; publish UNAVAILABLE if it does not. Use STARTING -> RUNNING -> STOPPING -> confirmed terminal state. Stop remains visible but disabled when inapplicable or already requested. NativeSupervisor implementation and callbacks must be wired by the host; no fake runtime is supplied.

Feed BoundedTerminalLog from a single serialized controller context, then publish snapshot() and droppedLines. It retains 1000 lines, clipping each to 4096 characters by default. Bound the upstream decoder, output queue and publication rate too; this class alone does not bound incoming process output. Keep diagnostic files under your separate retention policy. Use one log instance per session. Never mutate a published list.

Manual scrolling away from the bottom pauses following. The checkbox resumes it. Selection is per log row. This component uses wrapping text, not a full terminal emulator; ANSI, interactive stdin, cross-row selection, hex grids and split panes are outside this change.

## Verification

Source reviewed; Android compilation and device tests have not been performed. The supplied sample is not a buildable ETroute tree, and this environment has neither Gradle nor kotlinc available.

Device acceptance: verify small landscape windows, large fonts, keyboard opening/closing, system bars, Run/Stop reachability, stderr labels, idle/unavailable states, log eviction, follow pause/resume, rotation during execution, and confirmed process termination before cleanup. On extremely short windows or very large fonts, the header/input may consume most space: further adaptive compaction may be needed.

Expected controller-driven diagnostic example (not observed output):
RUNTIME=READY
SESSION=RUNNING
STOP_REQUESTED
PROCESS_EXIT_CONFIRMED
SESSION=COMPLETED

## Display controls update

Stop invokes onStop immediately, then requests keyboard dismissal without waiting for animation. The controller still owns STOPPING and confirmed termination.

Supply onClearDisplay to show Clear. On your serialized controller context, call log.clearDisplay() and publish a new state with lines = log.snapshot() and droppedLines = log.droppedLines. Do not change runtime phase, terminate execution, or remove diagnostic files. IDs continue increasing after clearing. If omitted, Clear is hidden; existing callers remain compatible.

Expected UI behavior (not observed Logcat): Stop signals the supervisor, the keyboard is dismissed, Clear empties only the displayed lines, and later output continues appearing.
